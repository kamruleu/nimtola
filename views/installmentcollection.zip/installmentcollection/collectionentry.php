
	<?php echo $this->dynform;?>
		<div class="panel panel-info"  style="">
            <div class="panel-heading">
                <div style="text-align: center;">
                    <h4><strong>Installment Detail</strong></h4> 
                </div>
			</div>
			<div id="printdiv">
			
			
			</div>
            <div class="panel-body">
				<?php echo $this->table;?>
			</div>				
			
        </div>
		
	
	
	